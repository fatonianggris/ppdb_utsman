/******/ (() => { // webpackBootstrap
    /******/ 	"use strict";
    var __webpack_exports__ = {};
    /*!*************************************************************!*\
     !*** ../demo1/src/js/pages/crud/file-upload/image-input.js ***!
     \*************************************************************/


// Class definition
    var KTImageInputDemo = function () {
        // Private functions
        var initDemos = function () {

            // Example 5
            var avatar = new KTImageInput('kt_image');

        };

        return {
            // public functions
            init: function () {
                initDemos();
            }
        };
    }();

    KTUtil.ready(function () {
        KTImageInputDemo.init();
    });

    /******/ })()
        ;
//# sourceMappingURL=image-input.js.map