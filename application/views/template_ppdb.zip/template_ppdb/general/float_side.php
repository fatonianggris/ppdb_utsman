<ul class="sticky-toolbar nav flex-column pl-2 pr-2 pt-3 pb-1 mt-4">
    <!--begin::Item-->
    <li class="nav-item mb-2" id="kt_demo_panel_toggle" data-toggle="tooltip" title="" data-placement="right" data-original-title="Butuh bantuan?">
        <a class="btn btn-sm btn-icon btn-bg-light btn-icon-success btn-hover-success" href="#">
            <i class="flaticon-whatsapp"></i>
        </a>
    </li>
    <!--end::Item-->          
</ul>